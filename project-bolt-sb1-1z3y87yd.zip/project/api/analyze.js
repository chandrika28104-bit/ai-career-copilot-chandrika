export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing the Gemini API key. Set GEMINI_API_KEY in Vercel environment variables.' });
  }

  const { resume, jobDesc } = req.body || {};

  if (!resume || !jobDesc) {
    return res.status(400).json({ error: 'Both resume and jobDesc are required.' });
  }

  const SYSTEM_PROMPT = `You are an expert career coach and ATS (Applicant Tracking System) specialist with 10+ years of experience helping professionals land their dream jobs at top companies.

Your task: Analyze the provided resume against the job description and provide detailed, actionable feedback.

You MUST return your analysis as a valid JSON object with these exact fields:
{
  "ats_score": <number 0-100, where 100 is perfect match>,
  "summary": "<2-3 sentence overall assessment, specific and data-backed>",
  "strengths": ["<strength 1>", "<strength 2>", "<strength 3>", "<strength 4>"],
  "missing_keywords": ["<keyword 1>", "<keyword 2>", "<keyword 3>", "<keyword 4>", "<keyword 5>"],
  "improvements": ["<specific actionable improvement 1>", "<specific actionable improvement 2>", "<specific actionable improvement 3>"]
}

Rules:
- Be SPECIFIC and DATA-BACKED. Use numbers where possible (e.g., "3 years experience" not "good experience")
- Focus on ACTIONABLE advice, not generic feedback
- missing_keywords must be actual keywords from the job description that are NOT in the resume
- strengths must highlight what the resume does WELL
- improvements must be specific changes the candidate can make
- Keep each item concise (1-2 sentences max)
- If information is missing, note it as a gap
- Do NOT include any text outside the JSON object`;

  const userPrompt = `Resume:\n${resume}\n\nJob Description:\n${jobDesc}\n\nProvide your analysis as a JSON object with the exact fields specified.`;

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: SYSTEM_PROMPT + "\n\n" + userPrompt }] }],
        generationConfig: { temperature: 0.3, maxOutputTokens: 2048 }
      })
    });

    const data = await response.json();

    if (!response.ok) {
      const message = data.error?.message || `Gemini API error: ${response.status}`;
      return res.status(502).json({ error: message });
    }

    const aiResponse = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!aiResponse) {
      return res.status(502).json({ error: 'Empty response from Gemini.' });
    }

    const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return res.status(502).json({ error: 'Gemini did not return valid JSON.' });
    }

    let analysis;
    try {
      analysis = JSON.parse(jsonMatch[0]);
    } catch {
      return res.status(502).json({ error: 'Failed to parse Gemini JSON output.' });
    }

    if (!analysis.ats_score || !analysis.strengths || !analysis.improvements) {
      return res.status(502).json({ error: 'AI response missing required fields.' });
    }

    return res.status(200).json({ analysis });
  } catch (error) {
    return res.status(500).json({ error: error.message || 'Unexpected server error.' });
  }
}
